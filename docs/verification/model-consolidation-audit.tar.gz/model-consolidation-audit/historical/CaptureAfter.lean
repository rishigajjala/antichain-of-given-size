import AntichainOfGivenSize
import Lean

open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private def captureKind : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

-- External evidence capture only: reads the loaded environment; writes no project file.
run_cmd do
  let env ← getEnv
  let selected : Array Name := #[`AntichainOfGivenSize.Model.ProblemSetting]
  for mod in selected do
    unless env.allImportedModuleNames.contains mod do
      throwError "Capture module is not imported: {mod}"
  let mut rows : Array Json := #[]
  for (name, ci) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let some mod := env.allImportedModuleNames[idx.toNat]? | continue
    unless selected.contains mod do continue
    let value := ci.value? (allowOpaque := true)
    let row := Json.mkObj [
      ("name", toJson name.toString),
      ("nameRepr", toJson (reprStr name)),
      ("userName", toJson (Lean.privateToUserName name).toString),
      ("module", toJson mod.toString),
      ("kind", toJson (captureKind ci)),
      ("levelParams", toJson (ci.levelParams.map Name.toString)),
      ("levelParamsRepr", toJson (reprStr ci.levelParams)),
      ("typeRepr", toJson (reprStr ci.type)),
      ("valueRepr", match value with
        | some v => toJson (reprStr v)
        | none => Json.null),
      ("typeUsedConstants", toJson (ci.type.getUsedConstants.toList.map Name.toString)),
      ("valueUsedConstants", toJson ((value.map (·.getUsedConstants.toList)).getD [] |>.map Name.toString))]
    rows := rows.push row
  let report := Json.mkObj [
    ("schema", toJson "antichain.raw-elaborated-environment-capture/1"),
    ("phase", toJson "after-six-module-consolidation"),
    ("modules", toJson (selected.toList.map Name.toString)),
    ("constantCount", toJson rows.size),
    ("includesOpaqueValues", toJson true),
    ("selection", toJson "All environment constants with getModuleIdxFor? defining module in the canonical ProblemSetting module; no name-prefix filter."),
    ("constants", Json.arr rows)]
  liftIO <| IO.FS.writeFile
    "/private/tmp/antichain-model-setting-consolidation-20261027/elaborated-after.json"
    report.compress
  logInfo m!"Captured {rows.size} constants from {selected.size} Model vocabulary modules to external JSON."
