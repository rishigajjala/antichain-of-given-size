import AntichainOfGivenSize.Model.BitMatchingVocabulary
import AntichainOfGivenSize.Model.PatternGadgetVocabulary
import AntichainOfGivenSize.Model.CountingVocabulary
import Mathlib.Data.Fintype.Prod

/-!
# Block-matching construction vocabulary

The original position and pattern generators, their ideal cardinality and
selected digits. Geometry, increment and size proofs remain in Paper/.
-/

open Finset
open scoped BigOperators

namespace AntichainOfGivenSize.Paper.UpperConstruction

open AntichainOfGivenSize.Section6

abbrev Index (r : ℕ) (K : Type*) := BitMatching.Index r ⊕ K

abbrev Vertex (r ell : ℕ) (V : Type*) := (BitMatching.Vertex r × Fin ell) ⊕ (V ⊕ BitMatching.Stage r)

noncomputable def oldUniverse (r : ℕ) : Finset (BitMatching.Vertex r) :=
  Finset.univ.disjSum (Finset.univ.disjSum ∅)

def selected {r : ℕ} {K : Type*} (i : BitMatching.Stage r) (D : Finset K) :
    Finset (Index r K) := (BitMatching.address i).disjSum D

noncomputable def Present {r ell : ℕ} {K V : Type*} [DecidableEq V]
    (active : Finset (BitMatching.Stage r)) (hist : BitMatching.Stage r → Finset K) (R : K → Finset V) :
    Index r K → Vertex r ell V → Prop
  | Sum.inl p, Sum.inl u => u.1 ∈ BitMatching.generator ∅ p
  | Sum.inr _, Sum.inl u => u.1 ∈ oldUniverse r
  | Sum.inl _, Sum.inr (Sum.inl _) => True
  | Sum.inr k, Sum.inr (Sum.inl v) => v ∈ R k
  | p, Sum.inr (Sum.inr g) => g ∈ active ∧ p ∈ selected g (hist g)

noncomputable def generator {r ell : ℕ} {K V : Type*} [Fintype V] [DecidableEq V]
    (active : Finset (BitMatching.Stage r)) (hist : BitMatching.Stage r → Finset K) (R : K → Finset V)
    (p : Index r K) : Finset (Vertex r ell V) := by
  classical
  exact Finset.univ.filter (Present active hist R p)

noncomputable def idealCard {r ell : ℕ} {K V : Type*}
    [Fintype K] [DecidableEq K] [Fintype V] [DecidableEq V]
    (active : Finset (BitMatching.Stage r)) (hist : BitMatching.Stage r → Finset K)
    (R : K → Finset V) : ℕ :=
  (generatedIdealIdx Finset.univ (generator (ell := ell) active hist R)).card

def digitSelection (ell d : ℕ) : Finset (PatternGadget.Index ell) :=
  PatternGadget.selected (PatternGadget.selectedBits ell d)

end AntichainOfGivenSize.Paper.UpperConstruction
