import Mathlib.Data.Fintype.Option
import Mathlib.Data.Fintype.Sum
import Mathlib.Data.Nat.BitIndices
import Mathlib.Order.Interval.Finset.Fin

/-!
# Pattern-gadget construction vocabulary

The original tagged generators and digit selection used by Claim 6.2.
Their qualified names and defining bodies are unchanged.
-/

open Finset

namespace AntichainOfGivenSize.Paper.PatternGadget

abbrev Vertex (ell : ℕ) := Fin ell ⊕ Fin ell

abbrev Index (ell : ℕ) := Option (Fin ell)

def baseline (ell : ℕ) : Finset (Vertex ell) :=
  Finset.univ.map Function.Embedding.inl

def initialSegment {ell : ℕ} (a : Fin ell) : Finset (Vertex ell) :=
  (Finset.Iio a).map Function.Embedding.inl

def generator {ell : ℕ} : Index ell → Finset (Vertex ell)
  | none => baseline ell
  | some a => insert (Sum.inr a) (initialSegment a)

def selected {ell : ℕ} (D : Finset (Fin ell)) : Finset (Index ell) :=
  insert none (D.image some)

def selectedBits (ell d : ℕ) : Finset (Fin ell) :=
  Finset.univ.filter fun a ↦ d.testBit a.val

end AntichainOfGivenSize.Paper.PatternGadget
