import AntichainOfGivenSize.Model.CountingVocabulary
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Sigma
import Mathlib.Data.Fintype.Sum
import Mathlib.Data.Nat.BitIndices

/-!
# Bit-matching construction vocabulary

The original binary addresses, vertices and generators, with their existing
qualified names and defining bodies. Their proofs remain in Paper/BitMatching.
-/

open scoped BigOperators
open Finset

namespace AntichainOfGivenSize.Paper.BitMatching

open AntichainOfGivenSize.Section6

abbrev Index (q : ℕ) := Fin q × Bool

abbrev Stage (q : ℕ) := Fin (2 ^ q)

abbrev BlockVertex (q : ℕ) := (j : Fin q) × Fin (2 ^ j.val)

abbrev Vertex (q : ℕ) := BlockVertex q ⊕ (Fin q ⊕ Stage q)

def chosenIndex {q : ℕ} (i : Stage q) (j : Fin q) : Index q :=
  (j, i.val.testBit j.val)

def chosenEmbedding {q : ℕ} (i : Stage q) : Fin q ↪ Index q where
  toFun := chosenIndex i
  inj' := by intro j k h; exact congrArg Prod.fst h

def address {q : ℕ} (i : Stage q) : Finset (Index q) :=
  Finset.univ.map (chosenEmbedding i)

def Present {q : ℕ} (active : Finset (Stage q)) (p : Index q) : Vertex q → Prop
  | Sum.inl e => e.1 ≠ p.1 ∨ p.2 = true
  | Sum.inr (Sum.inl j) => j ≠ p.1
  | Sum.inr (Sum.inr g) => g ∈ active ∧ p.2 = g.val.testBit p.1.val

noncomputable def generator {q : ℕ} (active : Finset (Stage q))
    (p : Index q) : Finset (Vertex q) := by
  classical
  exact Finset.univ.filter (Present active p)

noncomputable def intersection {q : ℕ} (active : Finset (Stage q))
    (J : Finset (Index q)) : Finset (Vertex q) := by
  classical
  exact Finset.univ.filter fun v => ∀ p ∈ J, Present active p v

def blockEmbedding {q : ℕ} (j : Fin q) : Fin (2 ^ j.val) ↪ Vertex q where
  toFun x := Sum.inl ⟨j,x⟩
  inj' := by intro x y h; simpa using h

noncomputable def block {q : ℕ} (j : Fin q) : Finset (Vertex q) :=
  Finset.univ.map (blockEmbedding j)

noncomputable def core {q : ℕ} (i : Stage q) : Finset (Vertex q) :=
  (Finset.univ.filter fun j : Fin q => i.val.testBit j.val = true).biUnion block

end AntichainOfGivenSize.Paper.BitMatching
