#!/usr/bin/env python3
"""Portable, sequential Lean replay; all output goes outside the checkout."""
from pathlib import Path
import argparse, datetime, hashlib, json, shutil, subprocess, sys, tempfile

HERE = Path(__file__).resolve().parent
SHA = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def validate_bundle():
    manifest = json.loads((HERE / "MANIFEST.json").read_text())
    for relative, expected in manifest["files"].items():
        path = HERE / relative
        if not path.is_file() or SHA(path) != expected["sha256"]:
            raise RuntimeError("Bundle checksum mismatch: " + relative)
    return manifest


def worker(output):
    manifest = validate_bundle()
    output = Path(output).resolve()
    report = {"schema": "antichain.portable-model-audit-rerun/1",
              "startedAtUTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "outputDirectory": str(output), "commands": [], "status": "RUNNING"}
    target = output / "rerun-report.json"
    try:
        for name in ["CaptureCurrent.lean", "CompareCapturedExpressions.lean"]:
            source = HERE / "portable" / name
            copied = output / name
            shutil.copyfile(source, copied)
            if SHA(source) != SHA(copied):
                raise RuntimeError("Probe copy changed: " + name)
            log = output / (name.removesuffix(".lean") + ".log")
            cmd = ["lean", "-DwarningAsError=true", "--root=" + str(output), str(copied)]
            with log.open("w") as stream:
                run = subprocess.run(cmd, cwd=output, stdout=stream, stderr=subprocess.STDOUT)
            report["commands"].append({"command": cmd, "exitCode": run.returncode,
                                        "log": log.name, "logSha256": SHA(log)})
            if run.returncode:
                raise RuntimeError("Lean check failed; inspect " + str(log))
        saved = json.loads((HERE / "historical/elaborated-after.json").read_text())
        current = json.loads((output / "elaborated-current.json").read_text())
        saved_rows = {x["name"]: x for x in saved["constants"]}
        current_rows = {x["name"]: x for x in current["constants"]}
        if len(saved_rows) != 78 or saved_rows != current_rows:
            changed = sorted(n for n in set(saved_rows) | set(current_rows)
                             if saved_rows.get(n) != current_rows.get(n))
            raise RuntimeError("Current captured constants differ: " + repr(changed))
        observed = [json.loads(line) for line in (output / "expression-comparison.jsonl").read_text().splitlines()]
        expected = [json.loads(line) for line in (HERE / "historical/expression-comparison.jsonl").read_text().splitlines()]
        if sorted(observed, key=lambda x:x["name"]) != sorted(expected, key=lambda x:x["name"]):
            raise RuntimeError("Kernel comparison results differ from the recorded78-declaration audit")
        log = (output / "CompareCapturedExpressions.log").read_text().strip()
        expected_log = (HERE / "historical/expression-comparison.log").read_text().strip()
        if log != expected_log:
            raise RuntimeError("Equality theorem diagnostics/axiom output changed")
        report.update(status="PASS", currentConstantCount=78,
                      typeEqualitiesCheckedByKernel=78,
                      bodyEqualitiesCheckedByKernel=74,
                      extensionalIntersectionEqualityChecked=True,
                      currentCaptureSha256=SHA(output / "elaborated-current.json"),
                      resultSha256=SHA(output / "expression-comparison.jsonl"),
                      note="Derivative Lean kernel audit only; no native receipt or workflow state change.")
    except Exception as error:
        report.update(status="FAIL", error=str(error))
    report["finishedAtUTC"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    target.write_text(json.dumps(report, indent=2) + "\n")
    print(report["status"] + ": " + str(target))
    return 0 if report["status"] == "PASS" else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--worker", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker is not None:
        return worker(args.worker)
    manifest = validate_bundle()
    if args.repo is None:
        parser.error("--repo is required")
    repo = args.repo.resolve()
    for relative, expected in manifest["requiredCheckoutPins"].items():
        path = repo / relative
        if not path.is_file() or SHA(path) != expected:
            raise RuntimeError("Checkout input changed: " + relative)
    if args.output is None:
        output = Path(tempfile.mkdtemp(prefix="antichain-model-audit-"))
    else:
        output = args.output.resolve()
        if output.exists() and any(output.iterdir()):
            raise RuntimeError("Output directory must be empty: " + str(output))
        output.mkdir(parents=True, exist_ok=True)
    if output == repo or repo in output.parents:
        raise RuntimeError("Choose an output directory outside the checkout")
    print("Results: " + str(output), flush=True)
    cmd = ["lake", "env", sys.executable, str(Path(__file__).resolve()), "--worker", str(output)]
    return subprocess.run(cmd, cwd=repo).returncode


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as error:
        print("FAIL: " + str(error), file=sys.stderr)
        sys.exit(1)
