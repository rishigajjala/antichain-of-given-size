# Model consolidation audit

This bundle records the check that moving six vocabulary files into
`Model/ProblemSetting.lean` preserved their mathematics. It includes all 78
captured declarations, not only source-written definitions.

All 78 types and 74 of 75 bodies agree after erasing bound-variable names. The
remaining `BitMatching.intersection` body selects another decision procedure.
The included Lean theorem proves the captured old function and the current
function extensionally equal. Raw byte identity is **not** claimed. The
successful theorem uses only `propext`, `Classical.choice` and `Quot.sound`.

## Rerun against a checkout

Use the repository's pinned Lean/Mathlib versions and build it first:

```sh
cd /absolute/path/to/antichain-of-given-size
lake build --wfail
python3 /absolute/path/to/model-consolidation-audit/run.py --repo "$PWD"
```

The script checks every bundle checksum and the toolchain, package manifest
and `ProblemSetting.lean` source pins. It uses `lake env` to run two Lean probes
sequentially in a fresh temporary directory. It does not change repository
sources or run a build. An optional `--output /new/empty/directory` retains
results at a chosen location. The default also retains its temporary results
and prints the path. `rerun-report.json` records commands, exit codes, logs
and comparisons. A nonzero exit means the rerun did not pass.

`portable/` uses only relative output paths. It does not depend on the original
machine's `/tmp` directory. `historical/` contains exact original files,
including their original output-path literals; those scripts are evidence,
not the portable entry points. The before-capture is historical input because
the six original modules no longer exist in the consolidated checkout. The
old source files are included for inspection, not as a complete old checkout.

The rerun checks the current environment against the saved after-capture,
then kernel-checks the raw old expressions and their equality with the current
expressions. It checks all 78 declarations and the extensional intersection
proof. No whole-library binary/cache or Mathlib source is included.

This is a mathematical preservation audit. It does not approve Tex2Lean
bindings, certify native workflow status, or establish completion of any
remaining manuscript target. See `SUMMARY.json` and `MANIFEST.json`.
